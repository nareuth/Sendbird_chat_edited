# Contributing

Our code maintenance policy doesn't allow to merge PR from external source. If you find a bug in this repository and want to report it, please report it in the ISSUE tab or send an email to 'support@sendbird.com'.  

Thank you for your interest in SendBird Android SDK.
